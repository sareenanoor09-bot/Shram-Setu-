# VBYLD 2027 submission: draft answers

Check every answer against the final prototype and video before submitting. Character limits are from the portal.

## 1. Problem/Concept Title (100 characters)

Shram Setu: Connecting Formal Jobs, Govt Posts and Skills for Hyderabad

## 2. Theme

Choose the dropdown option closest to employment and livelihoods.

## 3. Theme Description and UNSDG Alignment (500 characters)

Shram Setu aligns with SDG 8 (Decent Work) by connecting job seekers in Hyderabad to eligible formal and government posts. It supports SDG 4 (Quality Education) through skill-gap detection and low-cost course suggestions, and SDG 10 (Reduced Inequalities) by showing notifications to candidates who would otherwise miss them in scattered PDFs.

## 4. Problem Statement (500 characters)

Government and formal-sector vacancies in Telangana are spread across many portals and PDF notifications. Job seekers miss deadlines or don't realise they are eligible, and rarely see which certificate would unlock more posts. The public also cannot easily see how many sanctioned posts in schools, hospitals and offices are filled.

## 5. Solution Description (500 characters)

Shram Setu stores official-style vacancy records in a common format and matches seekers by qualification and district, showing why each post fits. For posts just out of reach, it names the missing qualification and suggests a verified low-cost course. A dashboard shows sanctioned versus filled posts by sector and district. Built with Python, pandas, SQLite and Streamlit.

## 6. Working Prototype (repository link)

Use your public GitHub repository URL. Make sure the repository is public before submitting.

## 7. Upload Submission Components

- Video (MP4 or MOV, 3 to 5 minutes, 720p or higher, up to 80 MB): follow `docs/demo_script.md`.
- PPT or PDF (up to 10 MB): use the official template from the portal, based on `docs/slides_outline.md`.
- Other design documentation (optional, up to 10 MB): export `docs/architecture.md` or a diagram.

## 8. Self Declaration by Team

Use the official template, fill it in, and upload it as a scanned PDF (up to 10 MB). Only tick the declaration once every team member has confirmed eligibility and agrees to the consent terms.
