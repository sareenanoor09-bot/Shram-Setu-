# Slide outline (use the official VBYLD template)

1. **Title:** Shram Setu. Connecting formal jobs, government posts and skills for Hyderabad. Team name, institution, track.
2. **The problem:** One real example of a missed teacher post. Vacancies spread across PDFs and portals.
3. **The idea:** Find, match, show the gap.
4. **How it works:** Official sources → cleaning → matching and skill-gap engine → dashboard and seeker app.
5. **Live demo:** Seeker match, skill-gap result, sanctioned-vs-filled chart.
6. **Evidence:** Number of records, percentage checked against the source, test results (`pytest`), accuracy of your test group.
7. **Limits:** Sample data, Hyderabad only, rule-based matching, PDF reading not yet automated.
8. **Scaling path:** Pilot → department partnership → second state → National Career Service integration.
9. **The ask and close:** Official data sharing, mentorship. "Jobs are already published. Shram Setu makes sure people can find them."
