# 3-minute demo script

Record in one take with the app already running. Keep a backup screen recording in case the internet fails.

**0:00 to 0:20. Problem.** "A teacher post in Medak was published as a PDF on a government site. Most people who could apply never saw it, and the deadline passed."

**0:20 to 0:40. Idea.** "Shram Setu collects formal vacancies, matches them to a person's qualification and district, and shows the skill gap."

**0:40 to 1:30. Live demo, seeker screen.**
- Select "B.Ed" and "Hyderabad".
- Point to the eligible teacher post. Show the official link and the last-checked date.
- Scroll to near matches. Point to the nursing post, the named skill gap, and the suggested free or low-cost course.

**1:30 to 2:20. Dashboard.**
- Open "Sanctioned vs filled".
- Show the vacancy totals and the chart by sector.
- Say clearly: "These numbers are synthetic sample data in this prototype."

**2:20 to 2:50. Honesty and next steps.**
- "Limits: sample data, Hyderabad only, rule-based matching. The AI step for reading PDFs is planned."
- "Next: partner with a department to get official data, then add a second state."

**2:50 to 3:00. Close.** "Jobs are already published. Shram Setu makes sure people can find them."

## Before you record

1. Run `python -m src.build_db` and `streamlit run src/dashboard.py`.
2. Test the demo once from start to finish.
3. Close other tabs and notifications.
4. Record at 720p or higher, landscape, with audio checked.
