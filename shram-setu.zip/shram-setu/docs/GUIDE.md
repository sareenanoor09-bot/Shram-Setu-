# Step-by-step guide

## A. Put the code on GitHub

1. Sign in at github.com and create a new **public** repository named `shram-setu`. Do not add a README or licence there, since this project already has them.
2. On your computer, open a terminal in the `shram-setu` folder and run:

   ```bash
   git init
   git add .
   git commit -m "Initial prototype: Shram Setu"
   git branch -M main
   git remote add origin https://github.com/<your-username>/shram-setu.git
   git push -u origin main
   ```

3. Check that the Actions tab shows the CI run passing.
4. Copy the repository URL. This goes into portal question 6.

## B. Run it locally first

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m src.build_db
pytest -q
streamlit run src/dashboard.py
```

If `pytest` fails, do not submit until it passes.

## C. Fill the portal form

Use `docs/portal_answers.md` as your source. Copy each answer into the matching box, check the character limit, and save.

## D. Record the video

Follow `docs/demo_script.md`. Export as MP4 at 720p, under 80 MB, 3 to 5 minutes.

## E. Build the slides

Open the official template from the portal and fill in the nine slides from `docs/slides_outline.md`.

## F. Team declaration

Download the declaration template from the portal, fill it in, sign it, scan it to PDF, and upload it. Each team member must confirm eligibility before the team lead submits.

## G. Submit and keep proof

1. Submit before the deadline. Sources disagree on the date, so check mybharat.gov.in and treat **27 October 2026** as the latest possible date.
2. Save a screenshot or PDF of the confirmation page.

## What still needs a human

- Replacing sample data with official records. Only official sources should be used.
- Confirming the team's eligibility and signing the declaration.
- Recording and uploading the video.
- Clicking submit on the portal.
