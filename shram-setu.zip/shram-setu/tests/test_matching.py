from datetime import date

import pandas as pd
import pytest

from src.matching import load_posts, match_posts

POSTS = pd.DataFrame(
    [
        {
            "post_id": "T1", "title": "Teacher", "department": "Education", "sector": "School",
            "district": "Hyderabad", "required_qualification": "B.Ed",
            "accepted_qualifications": "B.Ed|D.Ed", "deadline": "2030-01-01",
            "source_url": "https://example.gov.in/T1", "last_checked": "2026-10-20",
        },
        {
            "post_id": "N1", "title": "Nurse", "department": "Health", "sector": "Hospital",
            "district": "Hyderabad", "required_qualification": "GNM",
            "accepted_qualifications": "GNM", "deadline": "2030-01-01",
            "source_url": "https://example.gov.in/N1", "last_checked": "2026-10-20",
        },
        {
            "post_id": "OLD", "title": "Expired", "department": "Education", "sector": "School",
            "district": "Hyderabad", "required_qualification": "B.Ed",
            "accepted_qualifications": "B.Ed", "deadline": "2020-01-01",
            "source_url": "https://example.gov.in/OLD", "last_checked": "2019-12-01",
        },
    ]
)

COURSES = pd.DataFrame(
    [
        {"course_id": "C1", "course_name": "B.Ed Course", "provides_qualification": "B.Ed",
         "cost": "Paid", "duration_weeks": 104, "provider": "X", "source_url": "u"},
        {"course_id": "C2", "course_name": "GNM Course", "provides_qualification": "GNM",
         "cost": "Low cost", "duration_weeks": 156, "provider": "Y", "source_url": "u"},
        {"course_id": "C3", "course_name": "GNM Free", "provides_qualification": "GNM",
         "cost": "Free", "duration_weeks": 100, "provider": "Z", "source_url": "u"},
    ]
)

TODAY = date(2026, 10, 26)


def test_eligible_post_is_returned_as_eligible():
    results = match_posts(load_posts(POSTS), "B.Ed", "Hyderabad", COURSES, today=TODAY)
    eligible = [r for r in results if r.eligible]
    assert [r.post.post_id for r in eligible] == ["T1"]


def test_near_match_has_gap_and_course():
    results = match_posts(load_posts(POSTS), "B.Ed", "Hyderabad", COURSES, today=TODAY)
    near = [r for r in results if not r.eligible]
    assert [r.post.post_id for r in near] == ["N1"]
    assert near[0].gap_qualification == "GNM"


def test_free_course_is_preferred_over_low_cost():
    results = match_posts(load_posts(POSTS), "B.Ed", "Hyderabad", COURSES, today=TODAY)
    near = next(r for r in results if not r.eligible)
    assert near.suggested_course["course_name"] == "GNM Free"


def test_expired_posts_are_excluded():
    results = match_posts(load_posts(POSTS), "B.Ed", "Hyderabad", COURSES, today=TODAY)
    assert all(r.post.post_id != "OLD" for r in results)


def test_other_districts_are_excluded():
    results = match_posts(load_posts(POSTS), "B.Ed", "Medak", COURSES, today=TODAY)
    assert results == []


def test_eligible_posts_come_first():
    results = match_posts(load_posts(POSTS), "B.Ed", "Hyderabad", COURSES, today=TODAY)
    assert results[0].eligible is True
