# Shram Setu

**Connecting formal jobs, government posts and skills for Hyderabad.**

Shram Setu is a prototype for the VBYLD 2027 Hack for Social Cause track. It:

1. **Finds** formal vacancies from a set of official-style notification records (Telangana health, education and public service commission sources).
2. **Matches** a job seeker's qualifications and district to eligible posts, and shows why each post fits.
3. **Shows the skill gap** for each post the seeker almost qualifies for, with a suggested next step.
4. **Visualises** sanctioned versus filled posts by department and district on a dashboard.

> **Honesty note:** the data in `data/` is **synthetic sample data** for testing the pipeline. Before any real use, replace it with notifications collected from official sources and record the source URL and check date for every row.

## Quick start

```bash
git clone https://github.com/<your-username>/shram-setu.git
cd shram-setu
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 1. Build the local database from the sample CSVs
python -m src.build_db

# 2. Run the tests
pytest -q

# 3. Try matching from the command line
python -m src.match --qualification "B.Ed" --district "Hyderabad" --skills "computer basics"

# 4. Launch the dashboard and seeker app
streamlit run src/dashboard.py
```

## Project layout

```
shram-setu/
├── data/                 # synthetic sample CSVs (posts, departments, courses, sanctioned posts)
├── src/
│   ├── build_db.py       # loads CSVs into SQLite
│   ├── matching.py       # eligibility matching and skill-gap logic
│   ├── match.py          # command-line matcher
│   └── dashboard.py      # Streamlit dashboard and seeker form
├── tests/                # pytest tests for matching and gap logic
├── docs/
│   ├── portal_answers.md # draft answers for the VBYLD submission form
│   ├── demo_script.md    # 3-minute demo script
│   └── slides_outline.md # slide-by-slide pitch
├── .github/workflows/ci.yml
├── requirements.txt
└── LICENSE
```

## How matching works

Only posts in the seeker's chosen district are considered. A post is **eligible** when the seeker's qualification is in the post's accepted list. Expired posts are excluded.

For a post the seeker is *not* eligible for, the **skill gap** is the difference between the post's required qualification and the seeker's current one. Each gap is linked to a course from `data/courses.csv`, and only courses marked as free or low-cost are suggested.

Every result shows its source URL and the date the record was last checked.

## Limits

- Sample data only; not connected to any live government system.
- Matching is rule-based. The AI step for reading PDF notifications is described in `docs/` but not implemented in this prototype.
- Hyderabad district only in the sample data.

## Licence

MIT. See `LICENSE`.
