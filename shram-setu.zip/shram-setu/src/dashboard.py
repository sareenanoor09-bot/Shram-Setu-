"""Streamlit app: seeker matching and sanctioned-vs-filled vacancy dashboard.

Run with: streamlit run src/dashboard.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import plotly.express as px
import streamlit as st

# Make `src` importable when Streamlit runs this file directly.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.build_db import DB_PATH, build, load_table  # noqa: E402
from src.matching import load_posts, match_posts  # noqa: E402

st.set_page_config(page_title="Shram Setu", page_icon="🛠️", layout="wide")

if not DB_PATH.exists():
    build()

st.title("Shram Setu")
st.caption("Formal job matching, skill-gap guidance and vacancy visibility. Prototype using synthetic sample data.")

tab_seeker, tab_gap = st.tabs(["Find my posts", "Sanctioned vs filled"])

posts_df = load_table("posts")
courses_df = load_table("courses")
sanctioned_df = load_table("sanctioned_posts")

with tab_seeker:
    st.subheader("Enter your qualification and district")
    districts = sorted(posts_df["district"].unique())
    qualifications = sorted(
        {q for cell in posts_df["accepted_qualifications"] for q in cell.split("|")}
    )

    col1, col2 = st.columns(2)
    qualification = col1.selectbox("Your highest qualification", qualifications)
    district = col2.selectbox("Preferred district", districts)

    if st.button("Find posts", type="primary"):
        results = match_posts(load_posts(posts_df), qualification, district, courses_df)
        if not results:
            st.info("No open posts found for this qualification and district.")

        eligible = [r for r in results if r.eligible]
        near = [r for r in results if not r.eligible]

        st.markdown("### Posts you are eligible for")
        if not eligible:
            st.write("None right now.")
        for r in eligible:
            with st.container(border=True):
                st.markdown(f"**{r.post.title}**, {r.post.department}, {r.post.district}")
                st.write(f"Deadline: {r.post.deadline}")
                for reason in r.reasons:
                    st.write(f"- {reason}")
                st.markdown(f"[Official notification]({r.post.source_url})")
                st.caption(f"Last checked: {r.post.last_checked}")

        st.markdown("### Near matches and your skill gap")
        if not near:
            st.write("None.")
        for r in near:
            with st.container(border=True):
                st.markdown(f"**{r.post.title}**, {r.post.department}, {r.post.district}")
                st.write(f"Deadline: {r.post.deadline}")
                st.write(f"Skill gap: this post requires **{r.gap_qualification}**.")
                if r.suggested_course:
                    c = r.suggested_course
                    st.write(
                        f"Suggested next step: **{c['course_name']}** "
                        f"({c['cost']}, about {c['duration_weeks']} weeks, {c['provider']})."
                    )
                st.markdown(f"[Official notification]({r.post.source_url})")
                st.caption(f"Last checked: {r.post.last_checked}")

with tab_gap:
    st.subheader("Sanctioned versus filled posts")
    df = sanctioned_df.copy()
    df["vacancy"] = df["sanctioned_posts"] - df["filled_posts"]
    df["filled_pct"] = (df["filled_posts"] / df["sanctioned_posts"] * 100).round(1)

    c1, c2, c3 = st.columns(3)
    c1.metric("Sanctioned posts", int(df["sanctioned_posts"].sum()))
    c2.metric("Filled posts", int(df["filled_posts"].sum()))
    c3.metric("Vacant posts", int(df["vacancy"].sum()))

    fig = px.bar(
        df,
        x="sector",
        y=["filled_posts", "vacancy"],
        color_discrete_map={"filled_posts": "#2E7D32", "vacancy": "#E65100"},
        facet_col="district",
        barmode="stack",
        labels={"value": "Posts", "variable": "Status", "sector": "Sector"},
        title="Filled and vacant posts by sector and district",
    )
    st.plotly_chart(fig, use_container_width=True)

    st.dataframe(
        df[["department", "sector", "district", "sanctioned_posts", "filled_posts", "vacancy", "filled_pct", "source_note"]],
        use_container_width=True,
        hide_index=True,
    )
    st.caption("Figures in this prototype are synthetic. Replace with official department data before any real use.")
