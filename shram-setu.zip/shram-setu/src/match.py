"""Command-line matcher: python -m src.match --qualification "B.Ed" --district "Hyderabad"."""

from __future__ import annotations

import argparse

from src.build_db import DB_PATH, build, load_table
from src.matching import load_posts, match_posts


def main() -> None:
    parser = argparse.ArgumentParser(description="Match a seeker to formal posts.")
    parser.add_argument("--qualification", required=True, help="e.g. 'B.Ed', 'Graduate'")
    parser.add_argument("--district", required=True, help="e.g. 'Hyderabad'")
    args = parser.parse_args()

    if not DB_PATH.exists():
        build()

    posts = load_posts(load_table("posts"))
    courses = load_table("courses")
    results = match_posts(posts, args.qualification, args.district, courses)

    if not results:
        print("No open posts found for this qualification and district.")
        return

    for r in results:
        status = "ELIGIBLE" if r.eligible else "NEAR MATCH"
        print(f"[{status}] {r.post.post_id} {r.post.title} ({r.post.department}, {r.post.district})")
        print(f"   Deadline: {r.post.deadline}   Source: {r.post.source_url}")
        for reason in r.reasons:
            print(f"   - {reason}")
        if r.suggested_course:
            c = r.suggested_course
            print(f"   Suggested course: {c['course_name']} ({c['cost']}, {c['duration_weeks']} weeks)")
        print()


if __name__ == "__main__":
    main()
