"""Shram Setu: formal job matching, skill-gap guidance and vacancy dashboard."""
