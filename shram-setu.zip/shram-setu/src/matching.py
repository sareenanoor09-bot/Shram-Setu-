"""Eligibility matching and skill-gap logic. Rule-based and transparent."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Iterable, Optional

import pandas as pd


@dataclass
class Post:
    post_id: str
    title: str
    department: str
    sector: str
    district: str
    required_qualification: str
    accepted_qualifications: list[str]
    deadline: date
    source_url: str
    last_checked: date


@dataclass
class MatchResult:
    post: Post
    eligible: bool
    reasons: list[str] = field(default_factory=list)
    gap_qualification: Optional[str] = None
    suggested_course: Optional[dict] = None


def _split(value: str) -> list[str]:
    return [part.strip() for part in str(value).split("|") if part.strip()]


def load_posts(posts_df: pd.DataFrame) -> list[Post]:
    """Convert the posts table into Post objects."""
    posts = []
    for row in posts_df.itertuples(index=False):
        posts.append(
            Post(
                post_id=row.post_id,
                title=row.title,
                department=row.department,
                sector=row.sector,
                district=row.district,
                required_qualification=row.required_qualification,
                accepted_qualifications=_split(row.accepted_qualifications),
                deadline=date.fromisoformat(str(row.deadline)),
                source_url=row.source_url,
                last_checked=date.fromisoformat(str(row.last_checked)),
            )
        )
    return posts


def find_course(gap_qualification: str, courses_df: pd.DataFrame) -> Optional[dict]:
    """Return the best low-cost or free course that provides the missing qualification."""
    matches = courses_df[courses_df["provides_qualification"] == gap_qualification]
    if matches.empty:
        return None
    # Prefer free, then low cost, then anything else.
    order = {"Free": 0, "Low cost": 1, "Paid": 2}
    matches = matches.assign(_rank=matches["cost"].map(order).fillna(3))
    best = matches.sort_values("_rank").iloc[0]
    return best.drop(labels="_rank").to_dict()


def match_posts(
    posts: Iterable[Post],
    qualification: str,
    district: str,
    courses_df: pd.DataFrame,
    today: Optional[date] = None,
) -> list[MatchResult]:
    """Return eligible posts first, then near-matches with the skill gap and a course suggestion.

    Only posts in the seeker's district are considered. A post is eligible when the seeker's
    qualification is accepted for it; otherwise it is returned as a near match with the
    missing qualification and a suggested course. Expired posts are excluded.
    """
    today = today or date.today()
    results: list[MatchResult] = []

    for post in posts:
        if post.deadline < today:
            continue

        district_ok = post.district.lower() == district.lower()
        if not district_ok:
            continue

        if qualification in post.accepted_qualifications:
            results.append(
                MatchResult(
                    post=post,
                    eligible=True,
                    reasons=[
                        f"Your qualification '{qualification}' is accepted for this post.",
                        f"Post is in {post.district}, matching your district.",
                    ],
                )
            )
        else:
            course = find_course(post.required_qualification, courses_df)
            results.append(
                MatchResult(
                    post=post,
                    eligible=False,
                    reasons=[
                        f"This post requires '{post.required_qualification}'; you have '{qualification}'.",
                    ],
                    gap_qualification=post.required_qualification,
                    suggested_course=course,
                )
            )

    # Eligible posts first, then by nearest deadline.
    results.sort(key=lambda r: (not r.eligible, r.post.deadline))
    return results
