"""Load the sample CSVs into a local SQLite database."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DB_PATH = ROOT / "shram_setu.db"

TABLES = {
    "posts": "posts.csv",
    "sanctioned_posts": "sanctioned_posts.csv",
    "courses": "courses.csv",
}


def build(db_path: Path = DB_PATH, data_dir: Path = DATA_DIR) -> Path:
    with sqlite3.connect(db_path) as conn:
        for table, filename in TABLES.items():
            df = pd.read_csv(data_dir / filename)
            df.to_sql(table, conn, if_exists="replace", index=False)
    return db_path


def load_table(table: str, db_path: Path = DB_PATH) -> pd.DataFrame:
    with sqlite3.connect(db_path) as conn:
        return pd.read_sql_query(f"SELECT * FROM {table}", conn)


if __name__ == "__main__":
    path = build()
    print(f"Database built at {path}")
